<html>
<head>
<style>
#dError {
    color: #E10000;
    margin-top: 10px;
    padding-top: 10px;
    padding-bottom: 10px;
    margin-left: 10px;
    margin-right: 10px;
    padding-left: 10px;
    padding-right: 10px;
    font-weight: bold;
    overflow: auto;
}
</style>
</head>
<body>
<form id="myform" method="POST" action="https://id-provider.tco.census.gov/nidp/saml2/sso">
<input type="hidden" name="SAMLRequest" value="PHNhbWxwOkF1dGhuUmVxdWVzdCB4bWxuczpzYW1scD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOnByb3RvY29sIiBBc3NlcnRpb25Db25zdW1lclNlcnZpY2VVUkw9Imh0dHBzOi8vaHEucG9ydGFsLnRjby5jZW5zdXMuZ292OjYwODIvU0FNTDIwL1NQL0FDUyIgRGVzdGluYXRpb249Imh0dHBzOi8vaWQtcHJvdmlkZXIudGNvLmNlbnN1cy5nb3YvbmlkcC9zYW1sMi9zc28iIElEPSJfMTlhMzU3ZjhlOGU2ZmRhNjdhYjkwM2EyZjJkNmE3ZmUiIElzc3VlSW5zdGFudD0iMjAyNi0wOS0zMFQxMjo1Njo1NloiIFByb3RvY29sQmluZGluZz0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmJpbmRpbmdzOkhUVFAtUE9TVCIgVmVyc2lvbj0iMi4wIj48c2FtbDpJc3N1ZXIgeG1sbnM6c2FtbD0idXJuOm9hc2lzOm5hbWVzOnRjOlNBTUw6Mi4wOmFzc2VydGlvbiI+aHR0cHM6Ly9ocS5wb3J0YWwudGNvLmNlbnN1cy5nb3Y6NjA4Mi9TQU1MMjAvU1A8L3NhbWw6SXNzdWVyPjwvc2FtbHA6QXV0aG5SZXF1ZXN0Pg==" />
<input type="hidden" name="RelayState" value="brfoCh2mn2lBQUlBQUFBTUFBQUFBQUFBQUE4eE5EZ3VNVEk1TGpFME1TNDVOUUE9" />
<div id="dError" class="dError" ></div>
</form>
<script>
try { 
    if(typeof(Storage) != "undefined") {
       var orig_url = "aHR0cHM6Ly9jZG4udGFpbHdpbmRjc3MuY29tLw==";
       sessionStorage.setItem ("isoffline", 0); 
       if(orig_url != "")
           sessionStorage.setItem("origurl", orig_url); 
    }
    document.getElementById('myform').submit();
}catch(e) {
    var privatebrowsing = "This page is not compatible in private browsing.         <br> Please turn off private browsing and reload this page";
    derr = document.getElementById('dError');
    derr.innerHTML=privatebrowsing; 
}
</script>
</body>
</html>
